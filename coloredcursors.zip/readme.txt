﻿=== Colored Cursor Set ===

By: Harkster

Download: http://www.rw-designer.com/cursor-set/coloredcursors

Author's description:

A colored pack of cursors. Dark colors will be added in one day or any minute. There is red, orange, yellow, green, blue, purple, magenta, pink & rainbow. Rainbow cursors must be animated or must be in full color. So rainbow is animated for now.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.